import SettingsTab from "./tab";

export default function ChatOptionsTab(props: any) {
    return <SettingsTab name="chat" />
}