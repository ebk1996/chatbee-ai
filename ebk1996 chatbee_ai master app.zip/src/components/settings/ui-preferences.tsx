import SettingsTab from "./tab";

export default function UIPreferencesTab(props: any) {
    return <SettingsTab name="ui" />
}